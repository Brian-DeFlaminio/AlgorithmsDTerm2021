import java.util.LinkedList;
import java.util.Scanner;
//public class Main extends LucasNums{
public class Main extends MagicSquare{

	public static void main(String[] args) {
		@SuppressWarnings({ "unused", "resource" })
		Scanner scanner = new Scanner(System.in);
		
		MagicSquare subirachSquare = new MagicSquare();
		LinkedList<Integer> subirachsSquareList = new LinkedList<Integer>();
		subirachSquare.populateSquare(subirachsSquareList);
		System.out.println("The list of numbers is: " + subirachsSquareList);
		System.out.println("There are "+subirachSquare.fourElementCombosOf33(subirachsSquareList)+ " combos of 4 numbers that net 33");
		System.out.println("---------------------Please be patient...---------------------");
		System.out.println("There are "+subirachSquare.CombosNetting33(subirachsSquareList)+ " combos of any amount of numbers netting 33");
		System.out.println("There are "+(subirachSquare.greatestNumOfCombos(subirachsSquareList)+1)+ " possible sums of numbers");
		System.out.println("There are "+subirachSquare.totalCombos(subirachsSquareList)+ " combos of 132, which is the number with the largest amount of possible combos. It is 16 factorial");
		System.out.println();
		
		//LucasNums lucasNums = new LucasNums();
		//System.out.println("How many Lucas nums? Note: I wouldn't do more than 45, things get wacky at 45");
		//int lucasElements = scanner.nextInt();
		//System.out.println("The list of numbers is: " + lucasNums.lucasNumList(lucasElements) + "\nThe computation took "+ lucasNums.lucasNumsTimed(lucasElements) + " milliseconds\n");
		//System.out.println("The ratio is " +lucasNums.lucasRatio(lucasNums.lucasNumList(lucasElements))+ "\nThe time ratio is "+lucasNums.lucasTimeRatio(lucasNums.lucasTimeList(lucasElements)));
		
		
		//BrianNums BrianNums = new BrianNums();
		//System.out.println("How many Brian nums?");
		//int brianElements = scanner.nextInt();
		//System.out.println("The list of numbers is: " + BrianNums.brianNumList(brianElements) + "\nThe computation took "+ BrianNums.brianNumsTimed(brianElements) + " milliseconds\n");
		//System.out.println("The ratio is " +BrianNums.brianRatio(BrianNums.brianNumList(brianElements))+ "\nThe time ratio is "+BrianNums.brianTimeRatio(BrianNums.brianTimeList(brianElements)));
		
		
		
		
		//System.out.println("Here are some results for every 5 numbers");
		//System.out.println("\n________________________________________________________________________________________________________________________________\n");
		//System.out.println("The first 5 numbers are:" + lucasNums.lucasNumList(5) + "\nThe computation took "+ lucasNums.lucasNumsTimed(5) + " milliseconds");
		//System.out.println("\n________________________________________________________________________________________________________________________________\n");
		//System.out.println("The first 10 numbers are:" + lucasNums.lucasNumList(10) + "\nThe computation took "+ lucasNums.lucasNumsTimed(10) + " milliseconds");
		//System.out.println("\n________________________________________________________________________________________________________________________________\n");
		//System.out.println("The first 15 numbers are:" + lucasNums.lucasNumList(15) + "\nThe computation took "+ lucasNums.lucasNumsTimed(15) + " milliseconds");
		//System.out.println("\n________________________________________________________________________________________________________________________________\n");
		//System.out.println("The first 20 numbers are:" + lucasNums.lucasNumList(20) + "\nThe computation took "+ lucasNums.lucasNumsTimed(20) + " milliseconds");
		//System.out.println("\n________________________________________________________________________________________________________________________________\n");
		//System.out.println("The first 25 numbers are:" + lucasNums.lucasNumList(25) + "\nThe computation took "+ lucasNums.lucasNumsTimed(25) + " milliseconds");
		//System.out.println("\n________________________________________________________________________________________________________________________________\n");
		//System.out.println("The first 30 numbers are:" + lucasNums.lucasNumList(30) + "\nThe computation took "+ lucasNums.lucasNumsTimed(30) + " milliseconds");
		//System.out.println("\n________________________________________________________________________________________________________________________________\n");
		//System.out.println("The first 35 numbers are:" + lucasNums.lucasNumList(35) + "\nThe computation took "+ lucasNums.lucasNumsTimed(35) + " milliseconds");
		//System.out.println("\n________________________________________________________________________________________________________________________________\n");
		//System.out.println("The first 40 numbers are:" + lucasNums.lucasNumList(40) + "\nThe computation took "+ lucasNums.lucasNumsTimed(40) + " milliseconds");
		
		
	}

}
