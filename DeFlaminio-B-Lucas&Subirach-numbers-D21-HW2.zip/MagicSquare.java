import java.util.LinkedList;
import java.util.Scanner;

public class MagicSquare {

	Scanner scanner = new Scanner(System.in);
	LinkedList<Integer> magicSquare = new LinkedList<Integer>();
	
	public LinkedList<Integer> populateSquare(LinkedList<Integer> b){
		b.add(1);
		b.add(14);
		b.add(14);
		b.add(4);
		/////////
		b.add(11);
		b.add(7);
		b.add(6);
		b.add(9);
		/////////
		b.add(8);
		b.add(10);
		b.add(10);
		b.add(5);
		/////////
		b.add(13);
		b.add(2);
		b.add(3);
		b.add(15);
		return b;
	}
	
	/**
	 * checks for combos of 4 numbers that when added result in 33
	 * @param b the list in question
	 * @return the number of combinations that will result in 33
	 */
	public int fourElementCombosOf33 (LinkedList<Integer> b) {
		int numOfCombos = 0;
		//1,4,2,3 = 24 combos that all = 10
		for(int w = 0; w<b.size(); w++) {
			for(int x = 0; x<b.size(); x++) {
				for(int y = 0; y<b.size(); y++) {
					for(int z = 0; z<b.size(); z++) {
						if(((b.get(w)+b.get(x)+b.get(y)+b.get(z))==33) && (w!=x && w!=y && w!=z && x!=y && x!=z && y!=z)){
								numOfCombos++;			
						}
					}
					
				}
				
			}
			
		}
		return numOfCombos;
	}
	
	

	
	
	public int CombosNetting33 (LinkedList<Integer> b) {
		int numOfCombos = 0;
		
		for(int c = 0; c<b.size(); c++) {
			for(int d = 0; d<b.size(); d++) {
				for(int e = 0; e<b.size(); e++) {
					for(int f = 0; f<b.size(); f++) {
						for(int g = 0; g<b.size(); g++) {
							for(int h = 0; h<b.size(); h++) {
								for(int i = 0; i<b.size(); i++) {
									if(((b.get(c)+b.get(d)+b.get(e)+b.get(f)+b.get(g)+b.get(h)+b.get(i))==33) && (c!=d && c!=e && c!=f && c!=g && c!=h && c!=i && d!=e && d!=f && d!=g && d!=h && d!=i && e!=f && e!=g && e!=h && e!=i && f!=g && f!=h && f!=i && g!=h && g!=i && h!=i)){
											numOfCombos++;
									}
								}
								if(((b.get(c)+b.get(d)+b.get(e)+b.get(f)+b.get(g)+b.get(h))==33) && (c!=d && c!=e && c!=f && c!=g && c!=h && d!=e && d!=f && d!=g && d!=h && e!=f && e!=g && e!=h && f!=g && f!=h && g!=h)){
										numOfCombos++;
								}
							}
							if(((b.get(c)+b.get(d)+b.get(e)+b.get(f)+b.get(g))==33) && (c!=d && c!=e && c!=f && c!=g && d!=e && d!=f && d!=g && e!=f && e!=g && f!=g)){
								numOfCombos++;
						}			
					}
						if(((b.get(c)+b.get(d)+b.get(e)+b.get(f))==33) && (c!=d && c!=e && c!=f && d!=e && d!=f && e!=f)){
							numOfCombos++;
					}
				}
					if(((b.get(c)+b.get(d)+b.get(e))==33) && (c!=d && c!=e && d!=e)){
						numOfCombos++;
				}	
			}
				if(((b.get(c)+b.get(d))==33) && (c!=d)){
					numOfCombos++;
			}		
		}
			if(((b.get(c))==33)){
				numOfCombos++;
		}	
			
	}
		return numOfCombos;
	}
	
	
	public long totalCombos(LinkedList<Integer> b) {
		long factorial = 1;
		int total = b.size();
		for(int i = 2; i<=total; i++) {
			factorial=factorial*i;
		}
		return factorial;
	}

	
	
	
	public long totalCombosInt(int b) {
		long factorial = 1;
		int total = b;
		for(int i = 2; i<=total; i++) {
			factorial=factorial*i;
		}
		return factorial;
	}
	
	
	
	public long greatestNumOfCombos(LinkedList<Integer> b) {
		long grandTotal = 0;
		for(int i = b.size(); i>0; i--) {
			grandTotal = grandTotal + totalCombosInt(i);
		}
		return grandTotal;
	}
	
	
	
	
	
	
}

