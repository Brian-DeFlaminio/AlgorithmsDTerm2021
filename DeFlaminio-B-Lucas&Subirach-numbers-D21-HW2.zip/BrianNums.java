import java.util.LinkedList;
import java.util.Scanner;


public class BrianNums {
	

		
		
		Scanner scanner = new Scanner(System.in);
		
		public LinkedList<Integer> brianNumList(int n){
		LinkedList<Integer> brianList = new LinkedList<Integer>();
			for(int i = n; i<=n; i--) {
				brianList.add(brianNumbers(i));
				if(i==0) {
					return brianList;
				}
			}
			
			return brianList;
		}
		
		public int brianNumbers(int n) {
			// 2 1 3 4 7 11 18 29 47 76
			    if( n == 0 ) return 8;
			    if( n == 1 ) return 13;
			    return brianNumbers(n-1) + brianNumbers(n-2);
			}
		
		public long brianNumsTimed(int n) {
		
			long start = System.currentTimeMillis();
			brianNumList(n);
			long end = System.currentTimeMillis();
			return (end-start);
			
		}
		
		public LinkedList<Double> brianRatio(LinkedList<Integer> listOfNums) {
			LinkedList<Double> goldenRatio = new LinkedList<Double>();
			for(int i = 0; i<listOfNums.size()-1; i++) {
						goldenRatio.add((double)(listOfNums.get(i))/(double)(listOfNums.get(i+1)));
			}
			return goldenRatio;
		}
		
		
		
		public Double everyNumTimed(int n) {
			double start = System.currentTimeMillis();
			if( n == 0 ) return 8.0;
		    if( n == 1 ) return 13.0;
		    @SuppressWarnings("unused")
			int num = brianNumbers(n-1) + brianNumbers(n-2);
			double end = System.currentTimeMillis();
			return(end-start);
		}
		
		public LinkedList<Double> brianTimeList(int n){
			LinkedList<Double> brianTimeList = new LinkedList<Double>();
			for(int i = n; i<=n; i--) {
				brianTimeList.add(everyNumTimed(n));
				if(i==0) {
					return brianTimeList;
				}
			}
			return brianTimeList;
		}
		
		public LinkedList<Double> brianTimeRatio(LinkedList<Double> listOfNums) {
			LinkedList<Double> timeRatio = new LinkedList<Double>();
			for(int i = 0; i<listOfNums.size()-1; i++) {
						timeRatio.add((listOfNums.get(i))/(listOfNums.get(i+1)));
			}
			return timeRatio;
		}
		

		   
		
		
		
	}
		
