import java.util.LinkedList;
import java.util.Scanner;



public class LucasNums {

	
	
	Scanner scanner = new Scanner(System.in);
	
	/**
	 * takes in a number of elements to have in a created list of lucas numbers
	 * @param n the amount of elements in the list
	 * @return a list of lucas numbers
	 */
	public LinkedList<Integer> lucasNumList(int n){
	LinkedList<Integer> lucasList = new LinkedList<Integer>();
		for(int i = n; i<=n; i--) {
			lucasList.add(lucasNumbers(i));
			if(i==0) {
				return lucasList;
			}
		}
		
		return lucasList;
	}
	
	/**
	 * A naive way to calculate the lucas numbers
	 * @param n
	 * @return
	 */
	public int lucasNumbers(int n) {
		// 2 1 3 4 7 11 18 29 47 76
		    if( n == 0 ) return 2;
		    if( n == 1 ) return 1;
		    return lucasNumbers(n-1) + lucasNumbers(n-2);
		}
	
	public long lucasNumsTimed(int n) {
	
		long start = System.currentTimeMillis();
		lucasNumList(n);
		long end = System.currentTimeMillis();
		return (end-start);
		
	}
	
	public LinkedList<Double> lucasRatio(LinkedList<Integer> listOfNums) {
		LinkedList<Double> goldenRatio = new LinkedList<Double>();
		for(int i = 0; i<listOfNums.size()-1; i++) {
					goldenRatio.add((double)(listOfNums.get(i))/(double)(listOfNums.get(i+1)));
		}
		return goldenRatio;
	}
	
	
	
	public Double everyNumTimed(int n) {
		double start = System.currentTimeMillis();
		if( n == 0 ) return 2.0;
	    if( n == 1 ) return 1.0;
	    @SuppressWarnings("unused")
		int num = lucasNumbers(n-1) + lucasNumbers(n-2);
		double end = System.currentTimeMillis();
		return(end-start);
	}
	
	public LinkedList<Double> lucasTimeList(int n){
		LinkedList<Double> lucasTimeList = new LinkedList<Double>();
		for(int i = n; i<=n; i--) {
			lucasTimeList.add(everyNumTimed(n));
			if(i==0) {
				return lucasTimeList;
			}
		}
		return lucasTimeList;
	}
	
	public LinkedList<Double> lucasTimeRatio(LinkedList<Double> listOfNums) {
		LinkedList<Double> timeRatio = new LinkedList<Double>();
		for(int i = 0; i<listOfNums.size()-1; i++) {
					timeRatio.add((listOfNums.get(i))/(listOfNums.get(i+1)));
		}
		return timeRatio;
	}
	

	   
	
	
	
}
	
	
	

