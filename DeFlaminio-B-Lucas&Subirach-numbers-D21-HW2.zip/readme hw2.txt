Brian DeFlaminio 	

Question: 	
Have  your  code  examine  the  ratio  of  successive  calculations(L(n+1))/(L(n)) and
successive calculation times Time(L(n+1))/Time(L(n)).  Do you recognize these numbers?
What is the order of growth of your algorithm?

Answer(s):
The successive calculations ratios is the golden ratio and the successive calculation times is nearing 1.
The order of growth is roughly O(1.618^n)

The ratios of my own number set shares the same order of growth despite different initial conditions, 
everything is the same as the lucas numbers.


Question:
What sum can be created with the greatest number of combinations, and
how many combinations is that?  Notice anything interesting about that?

Answer(s):
132 is the sum with the greatest amount of combinations, the sum with the greatest amount of combination is always going to be whatever	
adding up every possible number is and the size of that list factorial is the amount of combinations you can make. 



**Note that some of the answers my code computes are commented out so it doesn't fry your computer or take forever!**

