import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;



public class Main {

	public static void main(String[] args) {

		
		// Read a file and hash the words:Read a text file (PaulReveresRide.txt from Canvas) and hash the words using the suggested hash function from Levitin, page 269:
		//Build a hash table of size 500,  i.e. entries from 000 to 499,  from the hash values computed in Part 1 above.  
		//Load them into the table in the order theyoccur in the file,discarding duplicates.  Our table will get close to full, but
		//you needn�t worry about re-sizing it�we will examine the effects of its loadfactor in Part 3 below.
		
		List<String> hashedWords = Arrays.asList(new String[500]);
		ArrayList<String> words = new ArrayList<>();
		Hash hashCode = new Hash();
		
		  Scanner scanner2 = null;
		    try {
		        scanner2 = new Scanner(new File("PaulReveresRide.txt"));
		    } catch (FileNotFoundException e) {
		        e.printStackTrace();  
		    }
		    
		    
		    while (scanner2.hasNextLine()) {
		            Scanner s2 = new Scanner(scanner2.nextLine());
		        while (s2.hasNext()) {
		            String word = s2.next();
		         
		        	 word = word.replace(",", "");
		        	 word = word.replace(".", "");
		        	 word = word.replace(":", "");
		        	 word = word.replace(";", "");
		        	 word = word.replace("\"", "");
		        	 word = word.replace("!", "");
		        	// word = word.replace("-", "");
		        	 word = word.replace("'", "");
		        	// System.out.println(word);
		        	
		        	 if(words.contains(word)==false) {
		        		 words.add(word); 
		        	 }
				
		        	 
		        }
				
			}
		 
		    
		    
		    for(int i = 0; i<words.size(); i++) {
		    	
		    	if(hashCode.findMTslot(hashCode.toHash(words.get(i)), hashedWords)==-1) {
		    		System.out.print("something went wrong");
		    	}
		    	else {
		    		hashedWords.set((hashCode.findMTslot(hashCode.toHash(words.get(i)), hashedWords)), words.get(i));
		    	}
		    }
		    
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		           
		   // Display the table, starting with table entry 0, in lines of the form:Hash Address, Hashed Word, Hash Value of Word    
		     for(int i = 0; i<hashedWords.size(); i++) {
		    	 if(hashedWords.get(i)!=null) {
		    		 System.out.println("\nHash address: " +hashCode.toHash(hashedWords.get(i))+"\t"+ "\tHashed Word: " + hashedWords.get(i)+"\t" + "\tHash Value of word: " +i +"\n");
		    	 }
		    	 else {
		    		 System.out.println("Hash address: n/a "+"\t"+ "\tHashed Word: null" +"\t" + "\tHash Value of word: " +i +"\n");
		    	 }
		    	
		     }
		     
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		     
		     // How many non-empty addresses are there in the table?  What does that make the load factor for our table?
		     int numEmpties = 0;
		     for(int i = 0; i<hashedWords.size(); i++) {
		    	 
		    	 if(hashedWords.get(i)==null) {
		    		 numEmpties++;
		    	 }
		     }
		     System.out.println("\nThere are "+(500-numEmpties)+" nonempty addresses in the table");
		     double loadFactor = (((500.0-numEmpties)/500.0)*100.0);
		     System.out.println("That means the load factor is "+loadFactor+"%");
		     
		    		
	
		    
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	//What is the longest empty area in the table, and where is it?
		     // this approach finds the first occuring longest chain of nulls
		     int mostEmpties = 0;
		     int startMT = 0;
		     int endMT = 0;
		     int finalStartMT = 0;
		     int finalEndMT = 0;
		     for(int i = 0; i<hashedWords.size()-1; i++) {
   	 
		    	 if(hashedWords.get(i)!=null && hashedWords.get(i+1)==null) {
		    		 startMT = i;
		    	 }
		    	 if(hashedWords.get(i)==null && hashedWords.get(i+1)==null) {
		    		 
		    	 }
		    	 if(hashedWords.get(i)==null && hashedWords.get(i+1)!=null) {
		    		 endMT = i;
		    		 
		    	 }
		    	 if(endMT-startMT>mostEmpties) {
		    		 mostEmpties = endMT-startMT;
		    		 finalStartMT = startMT+1;
		    		 finalEndMT = endMT+1;
		    	 }
		    	 
		     }
		     System.out.println("\nThe longest empty area in the table is "+ mostEmpties+ " long. The range of these is from position " +finalStartMT+ " to "+finalEndMT);
	
		     
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		     
		// What is the longest (largest) cluster in the table, and where is it? Note:  It might wrap from the end of the table back to the beginning.     
		     
		     int mostFilled = 0;
		     int startFill = 0;
		     int endFill = 0;
		     int finalStartFill = 0;
		     int finalEndFill = 0;
		     for(int i = 0; i<hashedWords.size()-1; i++) {
   	 
		    	 if(hashedWords.get(i)==null && hashedWords.get(i+1)!=null) {
		    		 startFill = i;
		    	 }
		    	 if(hashedWords.get(i)!=null && hashedWords.get(i+1)!=null) {
		    		 
		    	 }
		    	 if(hashedWords.get(i)!=null && hashedWords.get(i+1)==null) {
		    		 endFill = i;
		    		 
		    	 }
		    	 if(endFill-startFill>mostFilled) {
		    		 mostFilled = endFill-startFill;
		    		 finalStartFill = startFill+1;
		    		 finalEndFill = endFill+1;
		    	 }
		    	 
		     }
		     System.out.println("\nThe longest filled area in the table is "+ mostFilled+ " long. The range of these is from position " +finalStartFill+ " to "+finalEndFill); 
		     

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		     
		     //What hash value results from the greatest number of distinct words, and howmany words have that hash value?
		     
		     int maxOccurrences = 0;
		     int whichValue = 0;
		    
		     LinkedList<Integer> hashCollection = new LinkedList<Integer>();
		     
		     for(int i = 0; i<words.size(); i++) {
		    	 hashCollection.add(hashCode.toHash(words.get(i)));
		     }
		     
		     for (int i = 0; i<500; i++) {
				if(hashCode.countOccurences(i, hashCollection)>maxOccurrences) {
					maxOccurrences = hashCode.countOccurences(i, hashCollection);
					whichValue = i;
		    	}
		     }
		     
		     System.out.println("\nThe hash value that results from the greatest number of distinct words is: "+whichValue+", and that value occurs "+maxOccurrences+" times");
		     
		
		     
		     
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		     
		     
		     //What word is placed in the table farthest from its actual hash value, and how far away is it from its actual hash value?
		     // the word being word makes printing this out quite confusing so hopefully I provided enough info.
		     
		     System.out.println("\nThe word in the table placed the farthest from it's actual hash value is: "+hashedWords.get(hashCode.farthestVal(hashedWords).getLast()));	
		     System.out.println("The actual hash value of that word is "+hashCode.toHash(hashedWords.get(hashCode.farthestVal(hashedWords).getLast()))+" and it is "+hashCode.farthestVal(hashedWords).getFirst()+" positions away from that hash code value");
		     System.out.println("Meaning that the word \""+hashedWords.get(hashCode.farthestVal(hashedWords).getLast())+"\" is in position "+((hashCode.toHash(hashedWords.get(hashCode.farthestVal(hashedWords).getLast())))+(hashCode.farthestVal(hashedWords).getFirst())));
		     
		     
		     
		     
		     
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////vvvvv Starting part 4 vvvvv//////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
		     
		     
		 //I'm opting to hardcode the matrix, this main file is long enough as it is.
		     
		     Scanner scan = new Scanner(System.in);
		     
		     Dijkstra program = new Dijkstra();
		      
		     int adjacencyMatrix[][] = { {0,  50,  7,  9,  0,   0,   0,   0,   0,   0},
		    	 			  {50, 0,   30, 0,  2,   0,   98,  0,   0,   0},
		    	 			  {7,  30,  0,  6,  27,  15,  0,   0,   0,   0},
		    	 			  {9,  0,   6,  0,  0,   10,  0,   0,   3,   0},
		    	 			  {0,  2,   27, 0,  0,   11,  120, 105, 0,   0},
		    	 			  {0,  0,   15, 10, 11,  0,   0,   119, 4,   0},
		    	 			  {0,  98,  0,  0,  120, 0,   0,   5,   0,   66},
		    	 			  {0,  0,   0,  0,  105, 119, 5,   0,   122, 62},
		    	 			  {0,  0,   0,  3,  0,   4,   0,   122, 0,   190},
		    	 			  {0,  0,   0,  0,  0,   0,   66,  62,  190, 0}
};
		     
		     
		     System.out.println("\n\n\n\n\nPlease input a start node:");
		     int start = scan.nextInt();
		     System.out.println("Please input an end node:");
		     int end = scan.nextInt();
		     
		     
		     program.dijkstra(adjacencyMatrix, start, end);
		     
		     
		     
		     
		     
		     
		     
		     
		     
		     
		     
		scan.close();     
		     
	}

}

