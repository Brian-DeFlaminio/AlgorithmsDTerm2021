
import java.util.LinkedList;
import java.util.List;

public class Hash {

	/**
	 * Hash code based on the suggested hash function from Levitin
	 * @param word the word being hashed
	 * @return the hash value associated with that word
	 */
	public int toHash(String word) {
		int h = 0;
		for(int i = 0; i<word.length()-1; i++) {
			char letter = word.charAt(i);
			int asciiLetter = (int) letter;
			h = ((h*123+asciiLetter)%500);
		}
		return h;
	}
	
	
	public int findMTslot(int slotToCheck, List<String> hashedWords) {
			if(hashedWords.get(slotToCheck)==null) {
				return slotToCheck;
			}
			if(slotToCheck==499) {
				findMTslot(0, hashedWords);
			}
			else{
				return findMTslot(slotToCheck+1, hashedWords);
			}
			return -1;
	}
	
	
	public int countOccurences(int target, LinkedList<Integer> list) {
		int occurrences = 0; 
		for(int i = 0; i<list.size(); i++) {
			if(list.get(i)==target) {
				occurrences++;
			}
		}
		return occurrences;
	}
	
	
	//list it takes in is hashedWords
	public LinkedList<Integer> farthestVal(List<String> list) {
	// go through each thing in the list and do a word.toHash-hashValueFromList only keep the largest one
		int val = 0;
		int maxVal = 0;
		int savedPos = 0;
		LinkedList<Integer> answers = new LinkedList<Integer>();
		
		
		for(int i = 0; i<list.size(); i++) {
			if (list.get(i)!=null) {
				val = Math.abs(toHash(list.get(i))-i);
				if(val>maxVal) {
					maxVal = val;
					savedPos = i;
				}
			}
		}
		answers.add(maxVal);
		answers.add(savedPos);
		return answers;
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
