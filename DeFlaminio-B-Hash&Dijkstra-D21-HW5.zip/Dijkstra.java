public class Dijkstra {
	

	public static final int OrphanNode = -1;
	public static final int Sentinel = 10;

	/**
	 * a method that implements dijkstra's algorithm to find the best route from a specific node to a specific node 
	 * @param adjMatrix the adjacency matrix that represents the tree 
	 * @param start the user-specified start node
	 * @param end the user-specified end node
	 */
	public void dijkstra(int[][] adjMatrix, int start, int end) {

		//holds onto our distance values chosen
		int[] shortDists = new int[Sentinel];

		//keeps track of used nodes
		boolean[] added = new boolean[Sentinel];

		// Stops loops of infinite paths and makes sure we don't use used nodes again 
		for (int vIndex = 0; vIndex < Sentinel; vIndex++) {
			shortDists[vIndex] = Integer.MAX_VALUE;
			added[vIndex] = false;
		}
		
		// Distance of source vertex from itself is always 0
		shortDists[start] = 0;

		// "parent" array to store shortest path tree
		int[] parents = new int[Sentinel];

		// The starting vertex does not have any parent nodes
		parents[start] = OrphanNode;

		// Find shortest path for all vertices while not using the same vertex more than once
		for (int i = 1; i < Sentinel; i++) {	
			int nearestVertex = -1;
			int shortestDistance = Integer.MAX_VALUE;
			for (int vIndex = 0; vIndex < Sentinel; vIndex++) {
				if (!added[vIndex] && shortDists[vIndex] < shortestDistance) {
					nearestVertex = vIndex;
					shortestDistance = shortDists[vIndex];
				}
			}

			// marks the vertex as being processed and no longer available for selection
			added[nearestVertex] = true;

			// Updates the distance values of the adjacent vertices of the picked vertex so we can select the next best one
			for (int vIndex = 0; vIndex < Sentinel; vIndex++) {
				int edgeDist = adjMatrix[nearestVertex][vIndex];
				if (edgeDist > 0 && ((shortestDistance + edgeDist) < shortDists[vIndex])) {
					parents[vIndex] = nearestVertex;
					shortDists[vIndex] = shortestDistance + edgeDist;
				}
			}
		}
		printSolution(start, shortDists, parents, end);
	}

	
	
	
	
	/**
	 * a method to put it all together and print the desired start and end's shortest path
	 * @param start the start value specified by the user
	 * @param distances
	 * @param parents
	 * @param end the end value specified by the user
	 */
	public static void printSolution(int start, int[] distances, int[] parents, int end) {
		System.out.println("Vertexes\t Weight\t\tNode Path Taken");
		System.out.print("------------------------------------------------");
			if (end != start){
				System.out.print("\n" + start + " -> "+end + " \t\t "+distances[end] + "\t\t");
				printPath(end, parents);
			}
	}

	
	
	/**
	 * prints the shortest path from start to end 
	 * @param end the end value specified by the user
	 * @param parents
	 */
	public static void printPath(int end, int[] parents){
		
		if (end == OrphanNode){
			return;
		}
		printPath(parents[end], parents);
		System.out.print(end + " ");
	}
	
	
	
	
	
	
	
}
