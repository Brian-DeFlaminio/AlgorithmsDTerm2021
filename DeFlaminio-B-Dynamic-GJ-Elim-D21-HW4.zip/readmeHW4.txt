Brian DeFlaminio CS 2223 D-21 HW4

1. (5 Points) Explain why the ForwardElimination algorithm on page 210 of Levitin fails to provide a solution for:
x1 + x2 + x3 = 6
x1 + x2 + 2x3 = 9
x1 + 2x2 + 3x3 = 14

despite the fact that x = (1, 2, 3) or x1 = 1, x2 = 2, x3 = 3 can be easily verified as a solution to the system.

If the value in position A[i,i] = 0 then the division located in the innermost nested for loop is impossible to compute
as dividing by 0 is impossible. There also exists the issue that the value of A[1,1] is very small and dividing A[j,i] by an 
incredibly small number has the chance to cause an integer overflow and the correct number will be cut off/misrepresented
making our algorithm fail to provide a solution.



How does the BetterForwardElimination algorithm on page 211 of Levitin remedy this?

We solve the issue by searching for a row with the largest absolute value of the coefficient in the ith 
column, exchange it with the ith row and then use the new A[i,i] as the ith iteration's pivot. This change, called Partial 
pivoting, is used to remedy the problems that ForwardElimation was experiencing, using partial pivoting guarentees that the 
scaling factor will never exceed 1.



2. (10 Points) Explain in some detail why the BetterForwardElimination algorithm on page 211 of Levitin fails to provide a solution for:
x1 + x2 + x3 = 6
x1 + x2 + 2x3 = 9
2x1 + 2x2 + 3x3 = 15

despite the fact that x = (1, 2, 3) or x1 = 1, x2 = 2, x3 = 3 can be easily verified as a solution to the system.

We still face the problem of dividing by zero in BetterForwardElimination, if our pivot equals zeros we see this issue.




What can be done to remedy this shortcoming in the algorithm?

Whenever the pivot equals zero, skip that pivot.