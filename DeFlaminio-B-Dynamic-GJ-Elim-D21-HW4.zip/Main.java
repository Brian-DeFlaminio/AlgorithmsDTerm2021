

public class Main {

	public static void main(String[] args) {
		
		Dynamic treasureRoom = new Dynamic();
		GJElimination gje = new GJElimination();
		
		
		int treasureVault[][] = { {84,96,33,44,99,98,70,74},
								  {76,10,42,1,53,46,24,90},
								  {7,91,94,83,30,65,51,27},
								  {12,56,63,47,67,22,92,68},
								  {15,78,11,89,95,13,71,48},
								  {25,32,41,17,16,31,4,64},
								  {50,14,5,39,73,78,37,23},
								  {21,35,52,94,66,82,97,20}
		};
		
		System.out.println("The treasure vault problem's solution:\n");
		treasureRoom.findTotal(treasureVault, 8);
	
	
		System.out.println("\n\n\n");
		
		
		
		
		//float testmatrix[][] = {{ 0, 2, 1, 4 }, 
		//						{ 1, 1, 2, 6 }, 
		//						{ 2, 1, 1, 7 }};
		
		float theRealDeal[][] = {{1,1,1,1,1,6,1,1,1,1,1,0},
								 {1,1,1,1,5,1,5,1,1,1,1,0},
								 {1,1,1,4,1,1,1,4,1,1,1,0},
								 {1,1,3,1,1,1,1,1,3,1,1,0},
								 {1,2,1,1,1,1,1,1,1,2,1,0},
								 {11,1,1,1,1,1,1,1,1,1,1,10},
								 {1,6,1,1,1,1,1,1,1,1,1,10},
								 {1,1,5,1,1,1,1,1,1,1,1,12},
								 {1,1,1,3,1,1,1,1,1,1,1,10},
								 {1,1,1,1,2,1,1,1,1,1,1,7},
								 {1,1,1,1,1,1,1,1,1,1,1,0}
								 };

				System.out.println("The Matrix problem solution:\n");
			    int stopper = gje.GJElim(11, theRealDeal);
			      
			    if(stopper == 0)
			    	System.out.println("The final matrix of our 11x12 matrix is : ");
			    	gje.printMatrix(11, theRealDeal);
			    	System.out.println("\nThe solution to the matrix is:");
			    	gje.PrintSolutions(theRealDeal, 11);
			   
		
	}
                  
		

}


