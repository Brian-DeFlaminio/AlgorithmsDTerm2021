
public class GJElimination {

	public void printMatrix(int n, float matrix[][]) {
		for(int i = 0; i<n; i++) {
			for(int b = 0; b<=n; b++) {
				 System.out.print(matrix[i][b] + " | ");
			}
			System.out.println("");
			System.out.println("---------------------------------------------------------------------------------------");
		}
	}
	
	
	
	
	//Implements Gaussian elimination with partial pivoting
	//Input: Matrix A[1..n, 1..n] and column-vector b[1..n]
	//Output: An equivalent upper-triangular matrix in place of A and the
	//corresponding right-hand side values in place of the (n + 1)st column
	//	for i <- 1 to n do A[i, n + 1]<- b[i] //appends b to A as the last column
	//	for i <- 1 to n - 1 do
	//		pivotrow <- i
	//		for j <- i + 1 to n do
	//			if |A[j, i]| > |A[pivotrow, i]| pivotrow <- j
	//		for k <- i to n + 1 do
	//			swap(A[i, k], A[pivotrow, k])
	//		for j <- i + 1 to n do
	//			temp <- A[j, i] / A[i, i]
	//			for k <- i to n + 1 do
	//				A[j, k]<- A[j, k] - A[i, k] * temp
	
	
	
	/**
	 * A program that uses Gaussian-Jordan Elimination with partial pivoting to find the unique solution to a system of equations 
	 * @param n the amount of entries in each column
	 * @param matrix the matrix representing the system of equations we are trying to solve
	 * @return an int 
	 */
	public int GJElim (int n, float matrix[][])
	{
	    int stopper = 0;
	    
	    for (int a = 0; a < n; a++){
	        if (matrix[a][a] == 0){
	            int b = 1;
	            while ((a + b) < n && matrix[a + b][a] == 0){
	            	 b++;       
	            }
	            
	            for (int c = a, d = 0; d <= n; d++){
	                float temp =matrix[c][d];
	                matrix[c][d] = matrix[c+b][d];
	                matrix[c+b][d] = temp;
	            }
	        }
	        
	        for (int c = 0; c < n; c++){
	              if (a != c){
	                float p = matrix[c][a] / matrix[a][a];
	  
	                for (int d = 0; d <= n; d++) {
	                	 matrix[c][d] = (matrix[c][d]-((matrix[a][d])*p));             
	                }
	            }
	        }
	    }
	    return stopper;
	}
	

	
	/**
	 * prints out the solutions to the linear system matrix
	 * @param matrix the matrix in question
	 * @param n the amount of rows in the matrix
	 * @param stopper a predetermined value indicating what solutions the system has
	 */
	public void PrintSolutions(float matrix[][], int n) {
	        for (int i = 0; i < n; i++) {      
	        	int nextPrint = (int) (matrix[i][n] / matrix[i][i] );
	            System.out.print(nextPrint+" ");  
	        }
	    }
	
	
	
	
	
	




}
