import java.util.*;

public class Dynamic {
			
	//array[row][column]
	/**
	 * finds the next best choice from a given startpoint
	 * @param array the array of treasure values
	 * @param row the row it should be looking at
	 * @param column the column of the previously chosen number
	 * @return the next best choice 
	 */
	public void findTotal(int array[][], int length) {
		LinkedList<Integer> list = new LinkedList<Integer>();
		int total = 0;
		int sumOfPath[][] = new int[length][length + 2];
		
		//chooses row 8
		for (int column = 0; column < length; column++) {
			sumOfPath[0][column + 1] = array[0][column];
		}

		//chooses rows 7-1
		for (int row = 1; row < length; row++) {
			for (int column = 1; column < length; column++) {
				list.add(array[row][column - 1]);
				sumOfPath[row][column] = findMax((sumOfPath[row - 1][column - 1]), (sumOfPath[row - 1][column]), (sumOfPath[row - 1][column + 1])) + array[row][column - 1];
				
			}	
		}
			

		//finds the highest possible sum following the above rules for a subsequent choice
		for (int i = 0; i <= length; i++) {
			
			total = findMax((total), (sumOfPath[length - 1][i]), 0);
			
		}
		System.out.println("The highest possible total is: "+total);
		System.out.println("The numbers that add up to that sum are: (going from right to left) " +addCorrectSteps(list));
		System.out.println("The starting square was the square with the value " +addCorrectSteps(list).getLast());
		System.out.println("The final square was the square with the value " +addCorrectSteps(list).getFirst());
	}
	

	/**
	 * Finds the max out of 3 numbers
	 * @param a num 1
	 * @param b num 2
	 * @param c num 3
	 * @return the highest of the 3 numbers
	 */
	public int findMax(int a, int b, int c) {
		if(a>=b && a>=c) {
			return a;
		}
		if(b>=a && b>=c) {
			return b;
		}
		else {
			return c;
		}
	}
	
	
	/**
	 * sorts through the list of values attempted and creates a new list with only the correct choices
	 * @param list a list of all the attempts
	 * @return a list of the correct attempts
	 */
	public LinkedList<Integer> addCorrectSteps(LinkedList<Integer> list){
		LinkedList<Integer> lastList = new LinkedList<Integer>();
		for(int i=0; i<=list.size(); i= i+8) {
			lastList.add(list.get(i));
		}
		lastList.addFirst(96);
		return lastList;
	}

}
		

