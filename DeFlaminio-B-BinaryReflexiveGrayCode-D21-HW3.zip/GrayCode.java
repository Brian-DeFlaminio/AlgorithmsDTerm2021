import java.util.ArrayList;
public class GrayCode {

	ArrayList<String> bitsAndBytes = new ArrayList<String>();
	
	//else generate list L1 of bit strings of size n-1 by calling BRGC(n-1)
	//copy list L1 to list L2 in reversed order
	//add 0 in front of each bit string in list L1
	//add 1 in front of each bit string in list L2
	//append L2 to L1 to get list L
	
	
	/**
	 * produces binary reflexive gray code of order n
	 * @param n an int 
	 */
	public void BRGC(int n) {
		bitsAndBytes.add("0");
		bitsAndBytes.add("1");
		
	    for (int i=2; i < (2*n); i=i*2) 
	    { 
	    	//reverses the list
	        bitsAndBytes.addAll(reverseArrayList(bitsAndBytes)); 
	  
	        // add 0 in front of each bit string in list
	        for (int j = 0 ; j < i ; j++) 
	        	bitsAndBytes.set(j, "0" + bitsAndBytes.get(j)); 
	  
	        // add 1 in front of each bit string in list
	        for (int j = i ; j < 2*i ; j++) 
	        	bitsAndBytes.set(j, "1" + bitsAndBytes.get(j)); 
	    } 
	  
	    // print contents of bitsAndBytes[]
	    for (int i = 0 ; i < bitsAndBytes.size() ; i++ ) 
	        System.out.print(bitsAndBytes.get(i)+ " "); 
	} 

	
	
	/**
	 * Does the same thing as BRGC except it puts results in a list so that another program can operate on that list
	 * @param n an int
	 * @return a list of BRGC up to n
	 */
	public ArrayList<String> BRGClist(int n){
		ArrayList<String> bits = new ArrayList<String>();
		
		bitsAndBytes.add("0");
		bitsAndBytes.add("1");
		
	    for (int i=2; i < (2*n); i=i*2) 
	    { 
	    	//reverses the list
	        bitsAndBytes.addAll(reverseArrayList(bitsAndBytes)); 
	  
	        // add 0 in front of each bit string in list
	        for (int j = 0 ; j < i ; j++) { 
	        	bitsAndBytes.set(j, "0" + bitsAndBytes.get(j)); 
	        }
	  
	        // add 1 in front of each bit string in list
	        for (int j = i ; j < 2*i ; j++) {
	        	bitsAndBytes.set(j, "1" + bitsAndBytes.get(j)); 
	        }
	    } 
	  
	  // throw all the combos in a list
	    for (int i = 0 ; i < bitsAndBytes.size() ; i++ ) {
	       bits.add(bitsAndBytes.get(i)); 
	    }
	    return bits;
	}
	
	
	
	
		// Alexiev is 00001
		// Barack is 00010
		// Clarice is 00100
		// Darlene is 01000
		// Educardo is 10000
		/**
		 * Reads through the list produced by BRGClist and detects the change in each subsequent string of binary gray code
		 * @param n an int to go up to
		 */
		public void theAlgorithmics(int n) {
			
			ArrayList<String> bits =  BRGClist(n);
			for(int i = 0; i<bits.size(); i++) {
				if(i==0) {
					System.out.println("Silent Stage ");
				}
				
				if(i>=1) {
					
				
					if(bits.get(i-1).substring(4, 5).equals("1")&&bits.get(i).substring(4, 5).equals("0")) {
						System.out.println("Alexiev Fades ");
					}
					if(bits.get(i-1).substring(4, 5).equals("1")&&bits.get(i).substring(4, 5).equals("1")) {
						
					}
					if(bits.get(i).substring(4, 5).equals("1")&&bits.get(i-1).substring(4, 5).equals("0")) {
						System.out.println("Alexiev Joins ");
					}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
					if(bits.get(i-1).substring(3, 4).equals("1")&&bits.get(i).substring(4, 5).equals("1")) {
						
					}
					if(bits.get(i-1).substring(3, 4).equals("1")&&bits.get(i).substring(3, 4).equals("0")) {
						System.out.println("Barack Fades ");
					}
					if(bits.get(i).substring(3, 4).equals("1")&&bits.get(i-1).substring(3, 4).equals("0")) {
						System.out.println("Barack Joins ");
					}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
					if(bits.get(i-1).substring(2, 3).equals("1")&&bits.get(i).substring(4, 5).equals("1")) {
						
					}
					if(bits.get(i-1).substring(2, 3).equals("1")&&bits.get(i).substring(2, 3).equals("0")) {
						System.out.println("Clarice Fades ");
					}
					if(bits.get(i).substring(2, 3).equals("1")&&bits.get(i-1).substring(2, 3).equals("0")) {
						System.out.println("Clarice Joins ");
					}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////		
					if(bits.get(i-1).substring(1, 2).equals("1")&&bits.get(i).substring(4, 5).equals("1")) {
						
					}
					if(bits.get(i-1).substring(1, 2).equals("1")&&bits.get(i).substring(1, 2).equals("0")) {
						System.out.println("Darlene Fades ");
					}
					if(bits.get(i).substring(1, 2).equals("1")&&bits.get(i-1).substring(1, 2).equals("0")) {
						System.out.println("Darlene Joins ");
					}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
					if(bits.get(i-1).substring(0, 1).equals("1")&&bits.get(i).substring(4, 5).equals("1")) {
						
					}
					if(bits.get(i-1).substring(0, 1).equals("1")&&bits.get(i).substring(0, 1).equals("0")) {
						System.out.println("Eduardo Fades ");
					}
					if(bits.get(i).substring(0, 1).equals("1")&&bits.get(i-1).substring(0, 1).equals("0")) {
						System.out.println("Eduardo Joins ");
					}
					
					
				}
			}
				
			
				System.out.println("That's All Folks!");
		    
		}
	
	
	/**
	 * a simple program to reverse the order of elements in a ArrayList
	 * @param l the ArrayList we want to reverse the order of
	 * @return the reversed order ArrayList
	 */
	public ArrayList<String> reverseArrayList(ArrayList<String> l)
    {
        ArrayList<String> reversedList = new ArrayList<String>();
        for (int i = l.size() - 1; i >= 0; i--) {
            reversedList.add(l.get(i));
        }
        return reversedList;
    }
}
	

