
public class Palindromes {

	/**
	 * takes in a word or phrase and checks if it's a palindrome
	 * @param input a word or phrase
	 * @return true/false if the input is a palindrome or not
	 */
	public boolean palindromecheck(String input){
	
		input = input.replaceAll("\\s", "");
		input = input.replaceAll("[\\W]", "");
		input = input.toLowerCase();
		
		if(input.length() == 0 || input.length() == 1) {
			return true;
		}
		
		if((input.charAt(0))==(input.charAt(input.length()-1))){
			return palindromecheck(input.substring(1, input.length()-1));
		}
		
		return false;
	}

}
