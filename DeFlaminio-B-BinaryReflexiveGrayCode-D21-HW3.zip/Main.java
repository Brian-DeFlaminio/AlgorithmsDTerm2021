import java.util.Scanner;
public class Main {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		//Palindromes palindrome = new Palindromes();
		//ArrayInversions inversions = new ArrayInversions();
		GrayCode grayCodes = new GrayCode();
////////////////////////////////////////////////////////////////////////////////////////////////		
// Palindrome code		
////////////////////////////////////////////////////////////////////////////////////////////////
		//System.out.println("Please input a word/sentence to check if it's a palindrome");
		//String input = scan.nextLine();
		
		//if(palindrome.palindromecheck(input)) {
		//	System.out.println(input + " is a palindrome");
		//}
		//else {
		//	System.out.println(input + " is not a palindrome");
		//}
	
		
		
		
////////////////////////////////////////////////////////////////////////////////////////////////
// Array Inversions code
////////////////////////////////////////////////////////////////////////////////////////////////
		//int[] arrayTest = new int[] {3, 2, 1}; //should be 3 inversions
	//	int[] array1 = new int[] {5, 12, 18, 9, 4};
	//	int[] array2 = new int[] {13, 40, 12, 0, 99, 187, 8};
	//	int[] array3 = new int[] {100, 463, 2812, 909, 12, 204, 492, 6854, 584};
	//	int[] array4 = new int[] {100, 463, 2812, 909, 12, 204, 492, 6854, 584, 123, 5324, 5321, 52, 754, 7554, 794, 923, 246, 1723, 572, 184, 174, 9175, 5729, 1840, 1847, 7583, 1, 101, 30};
	//	System.out.println("What array inversion count method would you like to use? Enter 'fast' for the fastinversioncount method or 'easy' for the easyinversioncount method");
	//	String methodChoice = scan.nextLine();
		
	//	if (methodChoice.equalsIgnoreCase("fast")) {
	//		System.out.println("Please choose an existing array, type 1 2 3 or 4 to make your selection.\nArray 1 is [5, 12, 18, 9, 4]\nArray 2 is [13, 40, 12, 0, 99, 187, 8]\nArray 3 is [100, 463, 2812, 909, 12, 204, 492, 6854, 584]\nArray 4 is [100, 463, 2812, 909, 12, 204, 492, 6854, 584, 123, 5324, 5321, 52, 754, 7554, 794, 923, 246, 1723, 572, 184, 174, 9175, 5729, 1840, 1847, 7583, 1, 101, 30]  ");
	//		int whichArray = scan.nextInt();
	//		if (whichArray==1) {
	//			System.out.println("There are "+inversions.fastinversioncount(array1, 0, (array1.length-1))+ " inversions of the data set, this function used fastinversioncount");
	//		}
	//		if (whichArray==2) {
	//			System.out.println("There are "+inversions.fastinversioncount(array2, 0, (array2.length-1))+ " inversions of the data set, this function used fastinversioncount");
	//		}
	//		if (whichArray==3) {
	//			System.out.println("There are "+inversions.fastinversioncount(array3, 0, (array3.length-1))+ " inversions of the data set, this function used fastinversioncount");
	//		}
	//		if (whichArray==4) {
	//			System.out.println("There are "+inversions.fastinversioncount(array4, 0, (array4.length-1))+ " inversions of the data set, this function used fastinversioncount");
	//		}
	//	}
		
	//	if (methodChoice.equalsIgnoreCase("easy")) {
	//		System.out.println("Please choose an existing array, type 1 2 3 or 4 to make your selection.\nArray 1 is [5, 12, 18, 9, 4]\nArray 2 is [13, 40, 12, 0, 99, 187, 8]\nArray 3 is [100, 463, 2812, 909, 12, 204, 492, 6854, 584]\nArray 4 is [100, 463, 2812, 909, 12, 204, 492, 6854, 584, 123, 5324, 5321, 52, 754, 7554, 794, 923, 246, 1723, 572, 184, 174, 9175, 5729, 1840, 1847, 7583, 1, 101, 30]  ");
	//		int whichArray = scan.nextInt();
	//		if (whichArray==1) {
	//			System.out.println("There are "+inversions.easyinversioncount(array1)+ " inversions of the data set, this function used easyinversioncount");
	//		}
	//		if (whichArray==2) {
	//			System.out.println("There are "+inversions.easyinversioncount(array2)+ " inversions of the data set, this function used easyinversioncount");
	//		}
	//		if (whichArray==3) {
	//			System.out.println("There are "+inversions.easyinversioncount(array3)+ " inversions of the data set, this function used easyinversioncount");
	//		}
	//		if (whichArray==4) {
	//			System.out.println("There are "+inversions.easyinversioncount(array4)+ " inversions of the data set, this function used easyinversioncount");
	//		}
	//	}


		
////////////////////////////////////////////////////////////////////////////////////////////////
// Gray Code 
////////////////////////////////////////////////////////////////////////////////////////////////
		//grayCodes.BRGC(10);
		System.out.println("00000 00001 00011 00010 00110 00111 00101 00100 01100 01101 01111 01110 01010 01011 01001 01000 11000 11001 11011 11010 11110 11111 11101 11100 10100 10101 10111 10110 10010 10011 10001 10000");
		grayCodes.theAlgorithmics(10);
		
		
		scan.close();
	}

}
