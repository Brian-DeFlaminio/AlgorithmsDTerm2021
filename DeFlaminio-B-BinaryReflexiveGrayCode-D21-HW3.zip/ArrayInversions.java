import java.util.Arrays;

public class ArrayInversions {

	/**
	 * Naive algorithm to find inversions, more of a brute force approach, N^2 time complexity
	 * @param arr is the array in question
	 * @return the amount of inversions that can be found in the array
	 */
	public int easyinversioncount(int[] arr) {
		int total = 0;
		
		for (int j = 0; j < arr.length - 1; j++)
		{
			for (int b = j + 1; b < arr.length; b++)
			{
				if (arr[j] > arr[b]) {
					total++;
				}
			}
		}
		return total;
	}
	
	/**
	 * A function that takes an array and counts how many inversions, used in conjunction with the mergesort function
	 * to produce the number of inversions of a specific structure of the data
	 * @param arr is the array in question 
	 * @param left the position of the leftmost element, 0
	 * @param mid the position of the middle element, arraylength/2 usually
	 * @param right the position of the rightmost element, array.length
	 * @return an int representing the amount of inversions that can be made with the current state of the array.
	 */
	public int countNumOfInversions(int[] array, int l, int m, int r) {

		int[] leftArray = Arrays.copyOfRange(array, l, m + 1);
		int[] rightArray = Arrays.copyOfRange(array, m + 1, r + 1);

		int i = 0;
		int j = 0; 
		int k = l;
		int swaps = 0; 

		while (i < leftArray.length && j < rightArray.length) {
			if (leftArray[i] <= rightArray[j])
				array[k++] = leftArray[i++];
			else {
				array[k++] = rightArray[j++];
				swaps += (m + 1) - (l + i);
				}
		}
		
		while (i < leftArray.length)
		array[k++] = leftArray[i++];
		while (j < rightArray.length)
		array[k++] = rightArray[j++];
		
		return swaps;
		}
	
	
	/**
	 * Takes advantage of mergesort's divide and conquer algorithm to find all inversions of a specific set, 
	 * then adds up all of the inversions of those smaller sets and gets the total amount in far less time
	 * 
	 * @param arr the array being broken up and having it's inversions counted
	 * @param left the position of the leftmost element
	 * @param right the position of the rightmost element
	 * @return the total amount of inversions using mergesort to our advantage.
	 */
	public int fastinversioncount(int[] arr, int left, int right) {
		int total = 0;
		
		if(left<right) {
			int mid = ((left+right)/2);
			//left subarray
			total = total + fastinversioncount(arr, left, mid);
			//right subarray
			total = total +fastinversioncount(arr, mid+1, right);
			//merge them and count
			total = total +countNumOfInversions(arr, left, mid, right);
		}
		return total;
		
	}



}
